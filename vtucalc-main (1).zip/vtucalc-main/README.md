# vtucalc
VTU Calculator. This is a calculator used to calculate SGPA and CGPA of all semesters and branches of VTU.
